import React, { Component } from 'react';
import SubContents from './SubContents';
import Advertisement from './Advertisement';

class Main extends Component {
    render() {
        return <div style={{ backgroundColor: "#e06666", height: "500px", width: "737px", display: "inline-block", border: "black solid", margin: "15px 15px 15px 0px", verticalAlign: "top"}}>
            <SubContents />
            <SubContents />
            <SubContents />
            <Advertisement />
        </div>
    }
}

export default Main;