import React, { Component } from 'react';

class Navigation extends Component{
    render () {
        return <div style={{backgroundColor: "#6fa8dc", width: "175px", height: "400px", border: "black solid", margin: "15px 15px 0px 15px", display: "inline-block", verticalAlign: "top"}}></div>
    }
}

export default Navigation;