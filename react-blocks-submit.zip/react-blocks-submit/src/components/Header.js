import React, { Component } from 'react';

class Header extends Component {
    render () {
        return <div style={{backgroundColor: "#6aa84f", height: "110px", margin: "15px 15px 0px 15px", border: "solid black"}}></div>
    }
}

export default Header;