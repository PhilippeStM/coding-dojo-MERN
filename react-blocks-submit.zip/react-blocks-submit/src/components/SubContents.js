import React, { Component } from 'react';

class SubContents extends Component {
    render() {
        return <div style={{backgroundColor: "#ffd966", width: "220px", margin: "15px 0px 15px 15px", border: "solid black", height: "325px", display: "inline-block"}}></div>
    }
}

export default SubContents;