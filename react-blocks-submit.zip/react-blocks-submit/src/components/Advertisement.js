import React, { Component } from 'react';

class Advertisement extends Component{
    render () {
        return <div style={{backgroundColor: "#b4a7d6", height: "110px", width: "700px", border: "solid black", margin: "0px 15px 15px 15px"}}></div>
    }
}

export default Advertisement;